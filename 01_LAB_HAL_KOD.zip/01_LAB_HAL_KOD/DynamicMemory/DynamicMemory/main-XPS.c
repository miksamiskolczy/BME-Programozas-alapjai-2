﻿#include <stdio.h>
#include <stdlib.h>

int main() {

	//// Dinamikus primitív változó; ugyanígy a többire (double, float, ...)
	int* pMyInt = (int*)malloc(sizeof(int));
	if (pMyInt == NULL)
		return -1; // ha nem sikerült volna a foglalás (pl. elfogyott a memória)

	*pMyInt = 10;
	printf("pMyInt=%d\n", *pMyInt);
	free(pMyInt); // "Aki malloc()-ot mond, mondjon free()-t is!" ~ Dr. CZ; tehát ha nem szabadítjátok fel a dinamikusan lefoglalt memóriaterületet => while(--pontok);
	printf("pMyInt=%d\n", *pMyInt);

	//// Dinamikus 1D tömb
	double* pMyDoubleArray = (double*)malloc(sizeof(double) * 10);
	if (pMyDoubleArray == NULL)
		return -1;

	for (int i = 0; i < 10; i++) {
		pMyDoubleArray[i] = i*3.14;
		printf("pMyDoubleArray[%d]=%lf\n", i, pMyDoubleArray[i]);
	}

	//// Dinamikus 1D char tömb (C string)
	char* pMyCharArray = (char*)malloc(sizeof(char) * 10 + 1); // 10 hasznos karakter +1 null terminátor
	if (pMyCharArray == NULL)
		return -1;

	strcpy(pMyCharArray, "abcdefghij");
	printf("pMyCharArray=%s\n", pMyCharArray);
	free(pMyCharArray);

	//// 2D int tömb (10*20)
	printf("pMy2dArray[][]:\n");
	// inicializálás
	int** pMy2dArray = (int**)malloc(sizeof(int*) * 10); // először a sorokra mutató mutatóknak foglalunk
	for (int rowId = 0; rowId < 10; rowId++)
		pMy2dArray[rowId] = (int*)malloc(sizeof(int) * 20);

	// használat
	for (int row = 0; row < 10; row++) {
		for (int col = 0; col < 20; col++) {
			pMy2dArray[row][col] = row*col;
			printf("%d ", pMy2dArray[row][col]);
		}
		printf("\n");
	}

	// felszabadítás!
	for (int row = 0; row < 10; row++)
		free(pMy2dArray[row]);
	free(pMy2dArray);

	return 0;
}